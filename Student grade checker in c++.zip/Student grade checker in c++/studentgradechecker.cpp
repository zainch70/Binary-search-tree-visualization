#include<iostream>
#include<fstream>
using namespace std;

const int reg_size = 14;
const int name_size = 30;
const int cr_size = 20;

class tnode{
public:
	char regno[reg_size];
	char name[name_size];
	char course[cr_size];
	int grade;
	tnode *left, *right;

	tnode(char regno[], char name[], char course[], int grade)
	{
		for (int i = 0; regno[i] != '\0'; i++)
		{
			this->regno[i] = regno[i];
		}
		for (int i = 0; name[i] != '\0'; i++)
		{
			this->name[i] = name[i];
		}
		for (int i = 0; course[i] != '\0'; i++)
		{
			this->course[i] = course[i];
		}
		this->grade = grade;
		left = right = NULL;
	}
};

class studentgradechecker{
private:	
	tnode* insert(tnode* n, char rollno[],char name[], char course[], int grade) {
		
		if (n == NULL) 
		{
			return new tnode(rollno,name, course, grade);
		}
		if (grade < n->grade)
		{
			n->left = insert(n->left, rollno,name, course, grade);
		}
		else 
		{
			n->right = insert(n->right, rollno, name, course, grade);
		}
		return n;
	}

	void displayinorder(tnode *n)
	{
		if (n != NULL)
		{
			displayinorder(n->left);
			cout << "Rollno :" << n->regno << ", Student Name:" << n->name << ", Course :" << n->course << ", Grade :" << n->grade << endl;
			displayinorder(n->right);
		}
	}
	void displaypreorder(tnode *n)
	{
		if (n != NULL)
		{
			displaypreorder(n->left);
			cout << "Rollno :" << n->regno << ", Student Name:" << n->name << ", Course :" << n->course << ", Grade :" << n->grade << endl;
			displaypreorder(n->right);
		}
	}
	void displaypostorder(tnode *n)
	{
		if (n != NULL)
		{
			displaypostorder(n->left);
			cout << "Rollno :" << n->regno << ", Student Name:" << n->name << ", Course :" << n->course << ", Grade :" << n->grade << endl;
			displaypostorder(n->right);
		}
	}
	tnode *search(tnode *n, char regno[])
	{
		if (n == NULL)
		{
			return NULL; 
		}

		int cmp = strcmp(regno, n->regno);

		if (cmp < 0)
		{
			return search(n->left, regno);
		}
		else if (cmp > 0)
		{
			return search(n->right, regno);
		}
		else
		{
			return n; 
		}
	}

	tnode *update(tnode *n, char regno[])
	{
		tnode *temp=search(n, regno);

		if (temp != NULL)
		{
			int g;
			cout << "Student Found Enter Grade you want to update :";
			cin >> g;
			temp->grade = g;
			cout << "Rollno: " << temp->regno << ", Student Name: " << temp->name << ", Course: " << temp->course << ", Grade: " << temp->grade << endl;
			cout << "Grade Edit Successfully..\n" << endl;
		}
		else
		{
			cout << "Student with registration number " << n->regno << " not found.\n" << endl;
		}
		return temp;
	}

	tnode* minValueNode(tnode* n)
	{
		tnode* curr = n;
		while (curr && curr->left != NULL)
		{
			curr = curr->left;
		}
		return curr;
	}

	tnode* remove(tnode* n, char regno[]) 
	{
		if (n == NULL) 
		{
			return n;
		}
		int cmp = strcmp(regno, n->regno);

		if (cmp < 0) 
		{
			n->left = remove(n->left, regno);
		}
		else if (cmp > 0)
		{
			n->right = remove(n->right, regno);
		}
		else
		{
			if (n->left == NULL) 
			{
				tnode* temp = n->right;
				delete n;
				return temp;
			}
			else if (n->right == NULL) 
			{
				tnode* temp = n->left;
				delete n;
				return temp;
			}

			tnode* temp = minValueNode(n->right);
			*n = *temp;
			n->right = remove(n->right, temp->regno);
		}
		return n;
	}

public:
	tnode *root;
	studentgradechecker()
	{
		root = NULL;
	}

	void insert(char rollno[],char name[], char course[], int grade)
	{
		root = insert(root,rollno, name, course, grade);
	}
	
	void displayinorderhelper(tnode *n)
	{	
	    displayinorder(n);	
	}

	void displaypreorderhelper(tnode *n)
	{
		displaypreorder(n);
	}

	void displaypostorderhelper(tnode *n)
	{
		displaypostorder(n);
	}

	tnode* search(char regno[]) 
	{
		return search(root,regno);
	}
	tnode *update(char regno[])
	{
		return update(root, regno);
	}
	void remove(char regno[]) 
	{
		root = remove(root, regno);
	}

	tnode* maxgrade(tnode *n)
	{
		if (n == NULL)
		{
			return NULL;
		}
		while (n->right != NULL)
		{
			n = n->right;
		}
		return n;
	}

	tnode* mingrade(tnode *n)
	{
		if (n == NULL)
		{
			return NULL;
		}
		while (n->left != NULL)
		{
			n = n->left;
		}
		return n;
	}

	int max(int a, int b)
	{
		if (a > b)
		{
			return a;
		}
		else
		{
			return b;
		}
	}

	int getheight(tnode *n)
	{
		if (n == NULL)
		{
			return 0;
		}

		int left_height = getheight(n->left);
		int right_height = getheight(n->right);
		return 1 + max(left_height, right_height);
	}

};

void readfile(studentgradechecker &obj)
{
	ifstream fin;
	fin.open("data.txt");

	if (!fin.is_open())
	{
		cout << "File not found" << endl;
	}
	else
	{
		cout << "********************* Data For Student Is Given Below ***********************\n";
		char rollno[reg_size], name[name_size], course[cr_size];
		int grade;
		while (fin>>rollno>>name>>course>>grade)
		{
			obj.insert(rollno,name, course, grade);
			cout <<rollno<<" "<< name << " " << course << " " << grade << endl;
		}
		cout << endl;
	}
	fin.close();
}

int main()
{
	studentgradechecker obj;
	readfile(obj);

	int choice = -1;
	while (choice != 0)
	{
		cout << "Press 1 for displaying data from tree using inorder traversal" << endl;
		cout << "Press 2 for displaying data from tree using Preorder traversal" << endl;
		cout << "Press 3 for displaying data from tree using Postorder traversal" << endl;
		cout << "Press 4 for searching student data by student registration_no" << endl;
		cout << "Press 5 for updating grades" << endl;
		cout << "Press 6 For Removing Student name" << endl;
		cout << "Press 7 for Finding student of Maximum grade " << endl;
		cout << "Press 8 for Finding student of Minimum grade " << endl;
		cout << "Press 9 for getting the height of the tree" << endl;
		cout << "Press 0 to exit" << endl;

		cout << "\nEnter your choice: "; 
		cin >> choice;

		if (choice == 1)
		{
			cout << "\nData is dsiplaying using ----------------Inorder------------------\n" << endl;
			obj.displayinorderhelper(obj.root);
			cout << endl;
		}
		else if (choice == 2)
		{
			cout << "\nData is dsiplaying using ----------------Preorder------------------\n" << endl;
			obj.displaypreorderhelper(obj.root);
			cout << endl;
		}
		else if (choice == 3)
		{
			cout << "\nData is dsiplaying using ----------------Posrorder------------------\n" << endl;
			obj.displaypostorderhelper(obj.root);
			cout << endl;
		}
		else if (choice == 4)
		{
			char rollno[reg_size];
			cout << "Enter Student Registration number: ";
			cin >> rollno;
			tnode *temp = obj.search(rollno);
			if (temp != NULL)
			{
				cout << "Student Found: ";
				cout << "Rollno: " << temp->regno << ", Student Name: " << temp->name << ", Course: " << temp->course << ", Grade: " << temp->grade << endl << "\n";
			}
			else
			{
				cout << "Student with registration number " << rollno << " not found." << endl;
			}
		}
		else if (choice == 5)
		{
			char rollno[reg_size];
			cout << "Enter Student Registration number: ";
			cin >> rollno;
			
			obj.update(rollno);
		}
		else if (choice == 6)
		{
			char rollno[reg_size];
			cout << "Enter Student Registration number: ";
			cin >> rollno;

			tnode *temp = obj.search(rollno);
			if (temp != NULL)
			{
				obj.remove(rollno);
				cout << "Student with Rollno" << rollno << "Remove Successfully..\n" << endl;
			}
			else
			{
				cout << "Student with registration number " << rollno << " not found.\n" << endl;
			}
		}
		else if (choice == 7)
		{
			tnode *temp = obj.maxgrade(obj.root);
			cout << "Student with Max Grade : " << temp->regno << " " << temp->name << " " << temp->course << " " << temp->grade << endl << "\n";
		}
		else if (choice == 8)
		{
			tnode *temp = obj.mingrade(obj.root);
			cout << "Student with Max Grade : " << temp->regno << " " << temp->name << " " << temp->course << " " << temp->grade << endl << "\n";
		}
		else if (choice == 9)
		{
			cout<<"Height of the tree = "<<obj.getheight(obj.root)<<"\n\n";
		}
		else if (choice == 0)
		{
			break;
		}
		else
		{
			cout << "Please Press only Given Choices....\n" << endl;
		}
	}

	system("pause");
	return 0;
}
